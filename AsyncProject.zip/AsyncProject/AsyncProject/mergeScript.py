from subprocess import call
import sys

filenames = ['ByzantineReplica.da','ByzantineHelper.da', 'ByzantineParentProcess.da','ByzantineOlympus.da', 'ByzantineClient.da']
with open('BCR.da', 'w') as outfile:
    for fname in filenames:
        with open(fname) as infile:
            outfile.write(infile.read())


host_ip = "<enter source  ip>"
dest_ip = "<enter destination ip>"
NodeName = "<set-value as 'parent' in the source system>"

if NodeName == 'parent':
	call("python -m da -H "+host_ip +" -R "+ dest_ip+" -n ParentNode -D BCR.da", shell = True)
else:
	call("python -m da -H "+host_ip +" -n ClientNode BCR.da", shell = True)
